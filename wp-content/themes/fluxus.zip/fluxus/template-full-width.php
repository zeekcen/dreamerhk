<?php
/*
Template Name: Full Width

Template contents are the same as page.php.
*/

require_once get_template_directory() . '/page.php';